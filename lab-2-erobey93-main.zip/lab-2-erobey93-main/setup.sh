#!/bin/bash

sudo apt update && sudo apt install build-essential \
 libc6-dev wget curl git cmake \
 libx11-dev xorg-dev xserver-xorg-dev \
 libudev-dev libgl-dev libopenal-dev \
 libflac-dev libogg-dev libvorbis-dev \
 libsfml-dev
